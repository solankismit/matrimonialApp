import 'package:firebase_app_check/firebase_app_check.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:matrimonial_app/auth_screens/login_screen.dart';
import 'package:matrimonial_app/auth_screens/sign_up_screen.dart';
import 'package:matrimonial_app/main_screens/caste_screen.dart';
import 'package:matrimonial_app/main_screens/dashboard_screen.dart';
import 'package:matrimonial_app/main_screens/detail_screen.dart';
import 'package:matrimonial_app/main_screens/gender_screen.dart';
import 'package:matrimonial_app/main_screens/getting_started_screen.dart';
import 'package:matrimonial_app/main_screens/hometown_screen.dart';
import 'package:matrimonial_app/main_screens/multiple_profile_screen.dart';
import 'package:matrimonial_app/main_screens/profile_screens/profile_edit_screen.dart';
import 'package:matrimonial_app/main_screens/profile_screens/profile_screen.dart';
import 'package:matrimonial_app/main_screens/welcome_screen.dart';
import 'package:matrimonial_app/menu_screens.dart/accepted_req_screen.dart';
import 'package:matrimonial_app/menu_screens.dart/blocked_profile_screen.dart';
import 'package:matrimonial_app/menu_screens.dart/contact_us_screen.dart';
import 'package:matrimonial_app/menu_screens.dart/membership/membership_screen.dart';
import 'package:matrimonial_app/menu_screens.dart/membership/payment_screen.dart';
import 'package:matrimonial_app/menu_screens.dart/privacy_screen.dart';
import 'package:matrimonial_app/menu_screens.dart/sparkle_screen.dart';
import 'package:matrimonial_app/model/api.dart';
import 'package:matrimonial_app/onStarting.dart';
import 'package:matrimonial_app/onboarding.dart';
import 'package:matrimonial_app/auth_screens/otp_screen.dart';
// import 'package:matrimonial_app/otp/otp_screen.dart';
import 'package:matrimonial_app/provider/data_model.dart';
import 'package:matrimonial_app/utils/routes.dart';
import 'package:matrimonial_app/main_screens/profile_pic_screen.dart';
import 'package:matrimonial_app/widgets/dropdown_widgets/bio_widget.dart';
import 'package:matrimonial_app/main_screens/diet_screen.dart';
import 'package:matrimonial_app/widgets/dropdown_widgets/education_widget.dart';
import 'package:matrimonial_app/widgets/dropdown_widgets/home_town_widget.dart';
import 'package:matrimonial_app/widgets/dropdown_widgets/language_widget.dart';
import 'package:matrimonial_app/widgets/dropdown_widgets/occupation_widget.dart';
import 'package:matrimonial_app/widgets/dropdown_widgets/status_widget.dart';
import 'package:provider/provider.dart';

import 'main_screens/height_screen.dart';
import 'main_screens/profile_screens/family_details_screen.dart';
import 'main_screens/profile_screens/partner_preference_screen.dart';
import 'menu_screens.dart/membership/add_card_screen.dart';
import 'nav_bar_screens/user_details_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  await FirebaseAppCheck.instance.activate();

  // await FirebaseAppCheck.instance.activate();
  runApp(ChangeNotifierProvider(
    create: ((context) => DataModelProvider()),
    builder: (context, child) => MyApp(),
    // child: const MyApp(),
  ));
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
      designSize: Size(393, 810),
      builder: (context, child) => MaterialApp(
        title: 'Flutter Demo',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          fontFamily: GoogleFonts.poppins().fontFamily,
          // This is the theme of your application.
          //
          // Try running your application with "flutter run". You'll see the
          // application has a blue toolbar. Then, without quitting the app, try
          // changing the primarySwatch below to Colors.green and then invoke
          // "hot reload" (press "r" in the console where you ran "flutter run",
          // or simply save your changes to "hot reload" in a Flutter IDE).
          // Notice that the counter didn't reset back to zero; the application
          // is not restarted.
          primarySwatch: Colors.pink,
        ),
        home: SplashScreen(),
        // home: AddCardScreen(),
        // home: HomeTownScreen( firstName: '', lastName: '', email: '', phoneNumber: '', age: '', gender: '', dob: '', weight: 9, height: '',),
        // home: EducationWidget(
        //   email: "",
        //   firstName: "",
        //   lastName: "",
        //   phoneNumber: "",
        //   dob: "",
        //   age: "",
        //   gender: "",
        //   weight: 90,
        //   height: '',
        //   country: '',
        //   homeTown: '',
        //   religion: '',
        //   maritalstatus: '',
        //   community: '',
        //   nativeLanguage: '',
        //   settleDownTime: '',
        //   foodpreference: '',
        //   smokeStatus: '',
        //   drinkStatus: ''
        // ),
        routes: {
          MyRoutes.loginRoute: ((context) => LoginScreen()),
          // MyRoutes.signUpRoute: (context) => SignUpScreen(),
          MyRoutes.mainScreenRoute: (context) => WelcomeScreen(),
          MyRoutes.detailScreenRoute: (context) => DetailScreen(),
          // MyRoutes.genderScreenRoute: (context) => GenderScreen(),
          // MyRoutes.casteScreenRoute: (context) => CasteScreen(),
          // MyRoutes.profilepicScreenRoute: ((context) => ProfilePicker()),
          MyRoutes.profileScreenRoute: (context) => ProfileScreen(),
          MyRoutes.startScreenRoute: (context) => GettingStartedScreen(),
          MyRoutes.dashboardScreenRoute: (context) => DashboardScreen(),
          MyRoutes.acceptedReqScreenRoute: (context) => AcceptedRequestScreen(),
          MyRoutes.blockedProfileScreenRoute: (context) =>
              BlockedProfileScreen(),
          MyRoutes.contactUsProfileScreenRoute: (context) => ContactUsScreen(),
          MyRoutes.privayScreenRoute: (context) => PrivacyScreen(),
          MyRoutes.membershipScreenRoute: (context) => MembershipScreen(),
          MyRoutes.sparkleScreenRoute: (context) => SparkleScreen(),
          MyRoutes.editProfileScreenRoute: (context) => ProfileEditScreen(),
          MyRoutes.partnerPreferenceScreenRoute: (context) =>
              PartnerPreferenceScreen(),
          MyRoutes.familyDetailsScreenRoute: (context) => FamilyDetailsScreen(),
          MyRoutes.userProfileScreenRoute: (context) => UserDetailsScreen(),
          // MyRoutes.welcomeScreenRoute: (context) => WelcomeScreen(),
        },
      ),
    );
  }
}
