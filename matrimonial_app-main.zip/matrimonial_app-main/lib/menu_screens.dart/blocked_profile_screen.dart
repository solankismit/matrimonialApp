import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';

class BlockedProfileScreen extends StatelessWidget {
  const BlockedProfileScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
            image: DecorationImage(
                image: AssetImage("assets/bg2.png"), fit: BoxFit.cover)),
        child: Column(
          children: [
            SizedBox(
              height: 30.h,
            ),
            ListTile(
              leading: IconButton(
                icon: Icon(Icons.arrow_back_ios),
                onPressed: () => Navigator.of(context).pop(),
                color: Colors.black,
              ),
              title: Container(
                padding: EdgeInsets.only(left: 50.w),
                child: Text(
                  "Blocked Profile",
                  // textAlign: TextAlign.center,
                  style: GoogleFonts.inter(
                      fontWeight: FontWeight.w600, fontSize: 18),
                ),
                margin: EdgeInsets.only(left: 10.w),
              ),
            ),
            SizedBox(
              height: 80.h,
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Card(
                elevation: 10,
                child: ListTile(
                    leading: ClipRRect(
                      borderRadius: BorderRadius.circular(16),
                      child: Image.asset(
                        "assets/blocked_prof_pic.png",
                        height: 160.h,
                        width: 80.w,
                        fit: BoxFit.cover,
                      ),
                    ),
                    title: Text(
                      "Akshay, 23",
                      style: GoogleFonts.inter(
                          fontWeight: FontWeight.w700, fontSize: 18),
                    ),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "B.D.M",
                          style: GoogleFonts.inter(
                              fontWeight: FontWeight.w700, fontSize: 16),
                        ),
                        Text(
                          "Mumbai, India",
                          style: GoogleFonts.inter(
                              fontWeight: FontWeight.w700, fontSize: 14),
                        ),
                      ],
                    ),
                    isThreeLine: true,
                    trailing: TextButton(
                        style: ButtonStyle(
                            shape: MaterialStateProperty.all<
                                    RoundedRectangleBorder>(
                                RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(18.0),
                                    side:
                                        BorderSide(color: Color(0xff3C0A53))))),
                        onPressed: () {},
                        child: Container(
                          padding: EdgeInsets.symmetric(
                              vertical: 4.h, horizontal: 8.w),
                          child: Text(
                            "Unblock",
                            style: GoogleFonts.inter(
                                color: Color(0xff3C0A53),
                                fontWeight: FontWeight.w700,
                                fontSize: 15),
                          ),
                        ))),
              ),
            )
          ],
        ),
      ),
    );
  }
}
