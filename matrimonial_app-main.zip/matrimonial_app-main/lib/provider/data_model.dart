import 'package:flutter/material.dart';
class DataModelProvider with ChangeNotifier {
  // DataModel data;
  String firstName = "";
  String lastName = "";
  String name ="";
  String occupation = "";
  String companyName = "";
  String height = "";
  String status = "";
  String religion = "";
  String settleDown = "";
  String foodPreference = "";
  String homeTown = "";
}
//Store All the data in the provider
// class DataModelProvider with ChangeNotifier {
//   DataModel data;
//   DataModelProvider({required this.data});
//   void updateData(DataModel newData) {
//     data = newData;
//     notifyListeners();
//   }
// }
//
// class DataModel {
//   String firstName;
//   String lastName;
//   String occupation;
//   String companyName;

//   DataModel({
//     required this.firstName,
//     required this.lastName,
//     required this.occupation,
//     required this.companyName,
//   });
// }
//
// class DataModelProvider with ChangeNotifier {
//   DataModel data;
//   DataModelProvider({required this.data});
//   void updateData(DataModel newData) {
//     data = newData;
//     notifyListeners();
//   }
// }
