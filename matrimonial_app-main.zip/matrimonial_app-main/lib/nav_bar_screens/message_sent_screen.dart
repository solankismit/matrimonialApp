import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class MessageSentScreen extends StatelessWidget {
  const MessageSentScreen({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
            image: DecorationImage(
                image: AssetImage("assets/bg2.png"), fit: BoxFit.cover)),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(
              height: 100.h,
            ),
            Center(
                child: Stack(
              clipBehavior: Clip.none,
              children: <Widget>[
                ClipRRect(
                  borderRadius: BorderRadius.circular(40),
                  child: Card(
                    shadowColor: Colors.black,
                    elevation: 20,

                    // child: Container(
                    //   alignment: Alignment.bottomCenter,
                    //   height: 500.h,
                    //   width: 350.w,
                    //   padding: const EdgeInsets.all(16.0),
                    child: Stack(
                      children: [
                        Container(
                          width: 350.w,
                          height: 500.h,
                          child: Image.network(
                            // "assets/avatar.png",
                            "https://artriva.com/media/k2/galleries/8/matrimonial_5.jpg",
                            fit: BoxFit.cover,
                            width: 350.w,
                            height: 500.h,
                          ),
                        ),
                        Positioned(
                            // left: 5.w,
                            bottom: -10.h,
                            child: Container(
                              // alignment: Alignment.bottomLeft,
                              width: 400.w,
                              height: 500.h,
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.only(
                                      bottomLeft: Radius.circular(40.r),
                                      bottomRight: Radius.circular(40.r)),
                                  gradient: LinearGradient(
                                      colors: [
                                        Color(0xffb63c77),
                                        // Color(0xffd090ae)
                                        Colors.transparent
                                      ],
                                      begin: Alignment.bottomCenter,
                                      end: Alignment.topCenter)),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.end,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                      margin: EdgeInsets.only(left: 20.w),
                                      child: Text(
                                        "Tanmay 23",
                                        style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            fontSize: 30.sp,
                                            color: Colors.white),
                                      )),
                                  Container(
                                      margin: EdgeInsets.only(
                                          left: 20.w, bottom: 20.h),
                                      child: Text(
                                        "Ahmedabad",
                                        style: TextStyle(
                                            fontSize: 18.sp,
                                            color: Colors.white),
                                      ))
                                ],
                              ),
                            )),
                      ],
                    ),
                  ),
                ),
                // ),
                Positioned(
                    top: -20,
                    left: 50,
                    // top: 100,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Container(
                          // padding: EdgeInsets.symmetric(vertical: 10),
                          decoration: BoxDecoration(
                              boxShadow: [
                                new BoxShadow(
                                  color: Colors.black,
                                  blurRadius: 3.0,
                                ),
                              ],
                              borderRadius: BorderRadius.circular(24),
                              color: Colors.white),
                          width: 100,
                          child: IconButton(
                            icon: Icon(Icons.cancel_outlined),
                            color: Colors.black,
                            onPressed: () {},
                          ),
                        ),
                        SizedBox(
                          width: 20,
                        ),
                        Container(
                          // padding: EdgeInsets.symmetric(vertical: 10),

                          decoration: BoxDecoration(
                            boxShadow: [
                              new BoxShadow(
                                color: Colors.black,
                                blurRadius: 3.0,
                              ),
                            ],
                            border:
                                Border.all(width: 1, color: Color(0xffe9e9e9)),
                            borderRadius: BorderRadius.circular(24),
                            color: Colors.white,
                          ),
                          width: 140,
                          child: Row(
                            children: [
                              IconButton(
                                icon: Icon(Icons.favorite),
                                onPressed: () {},
                                color: Colors.red,
                              ),
                              Text(
                                "Interested",
                                style: TextStyle(fontWeight: FontWeight.bold),
                              )
                            ],
                          ),
                        ),
                      ],
                    )),
                // Positioned(
                //   top: 80.h,
                //   left: 5.w,
                //   child: Image.network(
                //     // "assets/avatar.png",
                //     "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRDA0iGvLaojcKNDqv09WvS1EY7n1qsc_UDzJNnIgYNNRzYqkA5sUiGsSZIRHq9TAp9jSk&usqp=CAU",
                //     fit: BoxFit.cover,
                //     width: 350.w,
                //     height: 350.h,
                //   ),
                // ),
              ],
            )),
          ],
        ),
      ),
    );
  }
}
