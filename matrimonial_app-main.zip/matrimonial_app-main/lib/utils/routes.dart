class MyRoutes {
  static String loginRoute = "/login_route";
  static String signUpRoute = "/signup_route";
  static String mainScreenRoute = "/main_screen_route";
  static String detailScreenRoute = "/detail_screen_route";
  static String genderScreenRoute = "/gender_screen_route";
  static String heightScreenRoute = "/height_screen_route";
  static String hometownScreenRoute = "/hometown_screen_route";
  static String casteScreenRoute = "/caste_screen_route";
  static String profilepicScreenRoute = "/profilepic_screen_route";
  static String profileScreenRoute = "/profile_screen_route";
  static String startScreenRoute = "/start_screen_route";
  static String dashboardScreenRoute = "/dashboard_screen_route";
  static String acceptedReqScreenRoute = "/acceptedreq_screen_route";
  static String blockedProfileScreenRoute = "/blockedprofile_screen_route";
  static String contactUsProfileScreenRoute = "/contactus_screen_route";
  static String privayScreenRoute = "/privacy_screen_route";
  static String membershipScreenRoute = "/membership_screen_route";
  static String sparkleScreenRoute = "/sparkle_screen_route";
  static String editProfileScreenRoute = "/editprofile_screen_route";
  static String partnerPreferenceScreenRoute =
      "/partnerpreference_screen_route";
  static String familyDetailsScreenRoute = "/familydetails_screen_route";
  static String userProfileScreenRoute = "/user_profile_screen_route";
}
