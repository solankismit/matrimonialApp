class sharedPrefsData{
  static String token = "user";
  static String id = "userId";
  static String phoneNo = "phone_no";

}